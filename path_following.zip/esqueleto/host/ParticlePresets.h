// Copyright (c) 2010-2011 Zipline Games, Inc. All Rights Reserved.
// http://getmoai.com

#ifndef	PARTICLEPRESETS_H
#define	PARTICLEPRESETS_H

//----------------------------------------------------------------//
void		ParticlePresets		();

#endif
