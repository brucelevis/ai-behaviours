#ifndef __GAME_CONFIG_H__
#define __GAME_CONFIG_H__

class MOAIGlobals;
void Configure(MOAIGlobals* globals);

#endif