#include "character.h"
#include "stdafx.h"
#include "steering.h"

Steering::Steering() {
}


Steering::~Steering() {
}

void Steering::Update(Accelerations &acc, Character * ch, USVec2D target) {

}